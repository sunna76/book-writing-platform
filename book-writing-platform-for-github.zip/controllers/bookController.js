const Book = require('../models/Book');

exports.createBook = async (req, res) => {
  const book = await Book.create({ title: req.body.title, author: req.user.id });
  res.status(201).json(book);
};

exports.getBooks = async (req, res) => {
  const books = await Book.find({ author: req.user.id });
  res.json(books);
};

exports.addChapter = async (req, res) => {
  const book = await Book.findOne({ _id: req.params.id, author: req.user.id });
  book.chapters.push(req.body);
  await book.save();
  res.status(201).json(book);
};

exports.updateChapter = async (req, res) => {
  const book = await Book.findOne({ _id: req.params.id, author: req.user.id });
  const chapter = book.chapters.id(req.params.chapterId);
  chapter.title = req.body.title;
  chapter.content = req.body.content;
  await book.save();
  res.json(book);
};
