const express = require('express');
const { createBook, getBooks, addChapter, updateChapter } = require('../controllers/bookController');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

router.use(authMiddleware);

router.post('/books', createBook);
router.get('/books', getBooks);
router.post('/books/:id/chapters', addChapter);
router.put('/books/:id/chapters/:chapterId', updateChapter);

module.exports = router;
