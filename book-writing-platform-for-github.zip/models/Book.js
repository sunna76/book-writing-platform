const mongoose = require('mongoose');

const chapterSchema = new mongoose.Schema({
  title: String,
  content: String
}, { timestamps: true });

const bookSchema = new mongoose.Schema({
  title: String,
  author: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  chapters: [chapterSchema]
}, { timestamps: true });

module.exports = mongoose.model('Book', bookSchema);
